import React, { Component} from 'react';
import Product from '../components/Product';
import { Object } from 'core-js';
let products = require('../seed');

class ProductList extends Component {
    // constructor(props) {
    //     super(props);

    //     this.state = {
    //         products: [],
    //     };

    //     this.handleProductUpVote = this.handleProductUpVote.bind(this);
    // }

    state = {
        products: [],
    }

    componentDidMount() {
        this.setState({products: products.Seed.products});
    }

    handleProductUpVote = (productId) => {
        //console.log(productId + ' was upvoted.');
        const nextProducts = this.state.products.map((product) => {
            if (product.id === productId) {
                return Object.assign({}, product, {
                    votes: product.votes + 1,
                });
            } else {
                return product;
            }
        });
        this.setState({
            products: nextProducts,
        });
    }

    render() {
        const data = this.state.products.sort((a, b) => (b.votes - a.votes));
        const productComponents = data.map((product) => (
            <Product
                key={'product-' + product.id}
                id={product.id}
                title={product.title}
                description={product.description}
                url={product.url}
                votes={product.votes}
                submitterAvatarUrl={product.submitterAvatarUrl}
                productImageUrl={product.productImageUrl}
                onVote={this.handleProductUpVote}
                />    
        ));
        return(
            <div className='ui unstackable items'>
                { productComponents }    
            </div>
        );
    }
}

export default ProductList
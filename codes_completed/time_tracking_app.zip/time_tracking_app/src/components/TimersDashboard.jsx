import React, { Component } from 'react';
import EditableTimerList from './EditableTimerList';
import ToggleableTimerForm from './ToggleableTimerForm';

//functions
window.helpers = (function () {
    function newTimer(attrs = {}) {
      const timer = {
        title: attrs.title || 'Timer',
        project: attrs.project || 'Project',
        id: ID(), 
        elapsed: 0,
      };
  
      return timer;
    }
  
    function findById(array, id, cb) {
      array.forEach((el) => {
        if (el.id === id) {
          cb(el);
          return;
        }
      });
    }
  
    function renderElapsedString(elapsed, runningSince) {
      let totalElapsed = elapsed;
      if (runningSince) {
        totalElapsed += Date.now() - runningSince;
      }
      return millisecondsToHuman(totalElapsed);
    }
  
    function millisecondsToHuman(ms) {
      const seconds = Math.floor((ms / 1000) % 60);
      const minutes = Math.floor((ms / 1000 / 60) % 60);
      const hours = Math.floor(ms / 1000 / 60 / 60);
  
      const humanized = [
        pad(hours.toString(), 2),
        pad(minutes.toString(), 2),
        pad(seconds.toString(), 2),
      ].join(':');
  
      return humanized;
    }
  
    function pad(numberString, size) {
      let padded = numberString;
      while (padded.length < size) padded = `0${padded}`;
      return padded;
    }
  
    return {
      millisecondsToHuman,
      newTimer,
      findById,
      renderElapsedString,
    };
  }());

//function
var ID = function () {
    // Math.random should be unique because of its seeding algorithm.
    // Convert it to base 36 (numbers + letters), and grab the first 9 characters
    // after the decimal.
    return '_' + Math.random().toString(36).substr(2, 9);
};

class TimersDashboard extends Component {
    state = {
        timers: [
            {
                title: 'Practice squat',
                project: 'Gym Chores',
                id: ID(),
                elapsed: 5456099,
                runningSince: Date.now(),
            },
            {
                title: 'Bake squash',
                project: 'Kitchen Chores',
                id: ID(),
                elapsed: 1273998,
                runningSince: null,
            },
        ],
    };

    handleStartClick = (timerId) => {
        this.startTimer(timerId);
    };
        
    handleStopClick = (timerId) => {
        this.stopTimer(timerId);
    };

    startTimer = (timerId) => {
        const now = Date.now();
        this.setState({
            timers: this.state.timers.map((timer) => {
                if (timer.id === timerId) {
                    return Object.assign({}, timer, {
                        runningSince: now,
                    });
                } else {
                    return timer;
                }
            }),
        });
    };
    
    stopTimer = (timerId) => {
        const now = Date.now();
        this.setState({
            timers: this.state.timers.map((timer) => {
                if (timer.id === timerId) {
                    const lastElapsed = now - timer.runningSince;
                    return Object.assign({}, timer, {
                        elapsed: timer.elapsed + lastElapsed,
                        runningSince: null,
                    });
                } else {
                    return timer;
                }
            }),
        });
    };

    handleTrashClick = (timerId) => {
        this.deleteTimer(timerId);
    };

    deleteTimer = (timerId) => {
        this.setState({
            timers: this.state.timers.filter(t => t.id !== timerId),
        });
    };

    handleCreateFormSubmit = (timer) => {
        this.createTimer(timer);
    };
    
    handleEditFormSubmit = (attrs) => {
        this.updateTimer(attrs);
    };
    
    createTimer = (timer) => {
        const t = window.helpers.newTimer(timer);
        this.setState({
        timers: this.state.timers.concat(t),
        });
    };
    
    updateTimer = (attrs) => {
        this.setState({
            timers: this.state.timers.map((timer) => {
                if (timer.id === attrs.id) {
                    return Object.assign({}, timer, {
                        title: attrs.title,
                        project: attrs.project,
                    });
                } else {
                    return timer;
                }
            }),
        });
    };

    render() {
        return (
            <div className='ui three column centered grid'>
                <div className='column'>
                    <EditableTimerList 
                        timers={this.state.timers}
                        onFormSubmit={this.handleEditFormSubmit}
                        onTrashClick={this.handleTrashClick}
                        onStartClick={this.handleStartClick}
                        onStopClick={this.handleStopClick}
                    />
                    <ToggleableTimerForm
                        onFormSubmit={this.handleCreateFormSubmit}
                    />  
                </div>
            </div>
        );
    }
}

export default TimersDashboard
import React, { Component } from 'react';
import TimerActionButton from './TimerActionButton';

//functions
window.helpers = (function () {
    function newTimer(attrs = {}) {
      const timer = {
        title: attrs.title || 'Timer',
        project: attrs.project || 'Project',
        id: ID(), // eslint-disable-line no-undef
        elapsed: 0,
      };
  
      return timer;
    }
  
    function findById(array, id, cb) {
      array.forEach((el) => {
        if (el.id === id) {
          cb(el);
          return;
        }
      });
    }
  
    function renderElapsedString(elapsed, runningSince) {
      let totalElapsed = elapsed;
      if (runningSince) {
        totalElapsed += Date.now() - runningSince;
      }
      return millisecondsToHuman(totalElapsed);
    }
  
    function millisecondsToHuman(ms) {
      const seconds = Math.floor((ms / 1000) % 60);
      const minutes = Math.floor((ms / 1000 / 60) % 60);
      const hours = Math.floor(ms / 1000 / 60 / 60);
  
      const humanized = [
        pad(hours.toString(), 2),
        pad(minutes.toString(), 2),
        pad(seconds.toString(), 2),
      ].join(':');
  
      return humanized;
    }
  
    function pad(numberString, size) {
      let padded = numberString;
      while (padded.length < size) padded = `0${padded}`;
      return padded;
    }
  
    return {
      millisecondsToHuman,
      newTimer,
      findById,
      renderElapsedString,
    };
  }());

//function
var ID = function () {
    // Math.random should be unique because of its seeding algorithm.
    // Convert it to base 36 (numbers + letters), and grab the first 9 characters
    // after the decimal.
    return '_' + Math.random().toString(36).substr(2, 9);
  };


class Timer extends Component {

    componentDidMount() {
        this.forceUpdateInterval = setInterval(() => this.forceUpdate(), 50);
    }

    componentWillUnmount() {
        clearInterval(this.forceUpdateInterval);
    }

    handleStartClick = () => {
        this.props.onStartClick(this.props.id);
    };
        
    handleStopClick = () => {
        this.props.onStopClick(this.props.id);
    };

    handleTrashClick = () => {
        this.props.onTrashClick(this.props.id);
    };

    render() {
        const elapsedString = window.helpers.renderElapsedString(
            this.props.elapsed, this.props.runningSince
          );
        return(
            <div className='ui centered card'>
                <div className='content'>
                    <div className='header'>
                        { this.props.title }
                    </div>
                    <div className='meta'>
                        { this.props.project }
                    </div>
                    <div className='center aligned description'>
                        <h2>
                            { elapsedString }
                        </h2>
                    </div>
                    <div className='extra content'>
                        <span
                            className='right floated edit icon'
                            onClick={this.props.onEditClick}
                        >
                            <i className='edit icon' />
                        </span>
                        <span
                            className='right floated trash icon'
                            onClick={this.handleTrashClick}
                        >
                            <i className='trash icon' />
                        </span>
                    </div>
                </div>
                {/* At the bottom of `Timer.render()`` */}
                <TimerActionButton
                timerIsRunning={!!this.props.runningSince}
                onStartClick={this.handleStartClick}
                onStopClick={this.handleStopClick}
                />
            </div>
        );
    }
}
export default Timer
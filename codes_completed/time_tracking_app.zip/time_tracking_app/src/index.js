import React from 'react';
import ReactDOM from 'react-dom';
import TimersDasboard from './components/TimersDashboard';

ReactDOM.render(
    <TimersDasboard />,
    document.getElementById('content')
);
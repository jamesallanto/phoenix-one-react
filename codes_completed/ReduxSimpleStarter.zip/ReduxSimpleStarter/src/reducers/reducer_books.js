export default function() {
    return [
        { title: 'JavaScript: The Good Parts'}, 
        { title: 'Harry Potter'},
        { title: 'The Source'},
        { title: 'The Horse'}
    ]
}
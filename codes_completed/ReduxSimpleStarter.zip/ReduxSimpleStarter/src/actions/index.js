export function selectBook(book) {
    return {
        type: 'BOOK_SELECTED', //for now we are using a string not const
        payload: book
    };
}
import React, { Component } from 'react';


class TimersDashboard extends Component {

    render() {
        return (
            <div className='ui three column centered grid'>
                Timers App
            </div>
        );
    }
}

export default TimersDashboard
import React, { Component } from 'react';
import ProductList from './ProductList';

class App extends Component {
    render() {
        return (
            <div>
                Products
            </div>
        )
    }
}

export default App